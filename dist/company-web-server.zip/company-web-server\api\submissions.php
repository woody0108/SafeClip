<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_fail(405, 'Only GET is allowed.');
}

$config = app_config();
$limit = max(1, min((int)($config['max_submissions'] ?? 50), 100));

$payload = firestore_request($config, 'POST', ':runQuery', [
    'structuredQuery' => [
        'from' => [['collectionId' => 'submissions']],
        'orderBy' => [[
            'field' => ['fieldPath' => 'createdAt'],
            'direction' => 'DESCENDING',
        ]],
        'limit' => $limit,
    ],
]);

$submissions = [];
foreach ($payload as $row) {
    if (!isset($row['document']) || !is_array($row['document'])) {
        continue;
    }

    $document = $row['document'];
    $fields = firestore_fields($document);
    $id = document_id_from_name((string)($document['name'] ?? ''));
    $videoPaths = find_video_paths($fields);

    $submissions[] = [
        'id' => $id,
        'status' => $fields['status'] ?? 'waiting_review',
        'ownerUid' => $fields['ownerUid'] ?? '',
        'guestId' => $fields['guestId'] ?? '',
        'ownerDisplayName' => $fields['ownerDisplayName'] ?? '',
        'ownerEmail' => $fields['ownerEmail'] ?? '',
        'originalFileName' => $fields['originalFileName'] ?? '',
        'incidentLocationText' => $fields['incidentLocationText'] ?? '',
        'violationTypeCandidate' => $fields['violationTypeCandidate'] ?? '',
        'userMemo' => $fields['userMemo'] ?? '',
        'createdAtText' => format_firestore_time((string)($fields['createdAt'] ?? '')),
        'videoPaths' => $videoPaths,
    ];
}

json_success(['submissions' => $submissions]);

function format_firestore_time(string $value): string
{
    if ($value === '') {
        return '';
    }

    $timestamp = strtotime($value);
    if ($timestamp === false) {
        return $value;
    }

    return date('Y-m-d H:i', $timestamp);
}
