const state = {
  submissions: [],
  selectedId: null,
  selectedCamera: 'front',
};

const listEl = document.querySelector('#submission-list');
const videoEl = document.querySelector('#review-video');
const refreshButton = document.querySelector('#refresh-button');
const completeButton = document.querySelector('#complete-button');
const frontTab = document.querySelector('#front-tab');
const rearTab = document.querySelector('#rear-tab');
const actionMessage = document.querySelector('#action-message');
const videoPlaceholder = document.querySelector('#video-placeholder');

const demoSubmissions = [
  {
    id: 'demo-submission-001',
    status: 'waiting_review',
    guestId: 'Guest-DEMO-0001',
    ownerDisplayName: '설정 전 샘플',
    originalFileName: 'front-rear-sample.mp4',
    incidentLocationText: '서울특별시 강남구 테헤란로',
    violationTypeCandidate: '추돌 사고',
    userMemo: 'Firestore 연결 전 화면 확인용 샘플입니다.',
    createdAtText: '설정 전 샘플',
    videoPaths: {
      front: '',
      rear: '',
    },
    demo: true,
  },
];

const labels = {
  uploading: '업로드중',
  waiting_review: '검토대기',
  reviewing: '검토중',
  needs_more_info: '추가정보필요',
  report_package_ready: '신고자료준비완료',
  rejected: '반려',
  completed: '완료',
};

refreshButton.addEventListener('click', loadSubmissions);
completeButton.addEventListener('click', completeSelectedSubmission);
frontTab.addEventListener('click', () => selectCamera('front'));
rearTab.addEventListener('click', () => selectCamera('rear'));

loadSubmissions();

async function loadSubmissions() {
  setMessage('제출 목록을 불러오는 중입니다.');
  listEl.innerHTML = '';

  try {
    const response = await fetch('api/submissions.php');
    const payload = await response.json();

    if (!payload.ok) {
      throw new Error(formatApiError(payload.error));
    }

    state.submissions = payload.submissions || [];
    state.selectedId = state.submissions[0]?.id || null;
    render();
    setMessage(state.submissions.length ? '' : '아직 제출 내역이 없습니다.');
  } catch (error) {
    state.submissions = demoSubmissions;
    state.selectedId = demoSubmissions[0].id;
    render();
    setMessage(error.message || 'Firestore 설정 전이라 샘플 화면을 보여줍니다.', true);
  }
}

function render() {
  renderMetrics();
  renderList();
  renderSelected();
}

function renderMetrics() {
  const total = state.submissions.length;
  const realItems = state.submissions.filter((item) => !item.demo);
  const waiting = state.submissions.filter((item) => item.status !== 'completed').length;
  const completed = state.submissions.filter((item) => item.status === 'completed').length;

  document.querySelector('#metric-total').textContent = String(realItems.length || total);
  document.querySelector('#metric-waiting').textContent = String(waiting);
  document.querySelector('#metric-completed').textContent = String(completed);
}

function renderList() {
  listEl.innerHTML = '';

  state.submissions.forEach((item) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `submission-card${item.id === state.selectedId ? ' active' : ''}`;
    button.innerHTML = `
      <strong>${escapeHtml(item.originalFileName || item.id)}</strong>
      <span>${escapeHtml(item.violationTypeCandidate || '유형 없음')}</span>
      <small>${escapeHtml(item.demo ? '설정 전 샘플' : item.createdAtText || item.guestId || item.ownerUid || '-')}</small>
    `;
    button.addEventListener('click', () => {
      state.selectedId = item.id;
      state.selectedCamera = item.videoPaths?.front ? 'front' : 'rear';
      render();
    });
    listEl.appendChild(button);
  });
}

function renderSelected() {
  const selected = selectedSubmission();
  const hasSelected = Boolean(selected);

  document.querySelector('#selected-title').textContent = selected?.originalFileName || '제출을 선택하세요';
  document.querySelector('#detail-id').textContent = selected?.id || '-';
  document.querySelector('#detail-user').textContent = selected?.ownerDisplayName || selected?.ownerEmail || selected?.guestId || selected?.ownerUid || '-';
  document.querySelector('#detail-location').textContent = selected?.incidentLocationText || '-';
  document.querySelector('#detail-type').textContent = selected?.violationTypeCandidate || '-';
  document.querySelector('#detail-memo').textContent = selected?.userMemo || '-';

  const status = selected?.status || 'waiting_review';
  const statusEl = document.querySelector('#selected-status');
  statusEl.className = `status-chip status-${status}`;
  statusEl.textContent = labels[status] || status;

  frontTab.disabled = !selected?.videoPaths?.front;
  rearTab.disabled = !selected?.videoPaths?.rear;
  frontTab.classList.toggle('active', state.selectedCamera === 'front');
  rearTab.classList.toggle('active', state.selectedCamera === 'rear');

  const path = selected?.videoPaths?.[state.selectedCamera];
  if (hasSelected && path) {
    videoEl.src = `api/video.php?id=${encodeURIComponent(selected.id)}&camera=${state.selectedCamera}`;
    videoPlaceholder.classList.add('hidden');
  } else {
    videoEl.removeAttribute('src');
    videoEl.load();
    videoPlaceholder.classList.remove('hidden');
    videoPlaceholder.textContent = selected?.demo
      ? 'Firestore와 NAS 영상 경로를 연결하면 여기에 영상이 나옵니다.'
      : '이 제출에는 아직 영상 경로가 없습니다.';
  }

  completeButton.disabled = !hasSelected || status === 'completed' || Boolean(selected?.demo);
}

function selectCamera(camera) {
  state.selectedCamera = camera;
  renderSelected();
}

async function completeSelectedSubmission() {
  const selected = selectedSubmission();
  if (!selected) {
    return;
  }

  setMessage('검토완료 처리 중입니다.');
  completeButton.disabled = true;

  try {
    const response = await fetch('api/status.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: selected.id, status: 'completed' }),
    });
    const payload = await response.json();

    if (!payload.ok) {
      throw new Error(payload.error || '상태 변경에 실패했습니다.');
    }

    selected.status = 'completed';
    render();
    setMessage('Firestore 상태가 completed로 변경되었습니다.');
  } catch (error) {
    completeButton.disabled = false;
    setMessage(error.message || '상태 변경에 실패했습니다.');
  }
}

function selectedSubmission() {
  return state.submissions.find((item) => item.id === state.selectedId) || null;
}

function setMessage(message, warning) {
  actionMessage.classList.toggle('warning', Boolean(warning));
  actionMessage.textContent = message;
}

function formatApiError(error) {
  if (!error) {
    return 'Firestore 설정 전이라 샘플 화면을 보여줍니다.';
  }

  if (error.includes('config.php')) {
    return 'NAS에 config.php가 아직 없어서 샘플 화면을 보여줍니다.';
  }

  if (error.includes('service account')) {
    return 'Firebase 서비스 계정 JSON 연결 전이라 샘플 화면을 보여줍니다.';
  }

  return `${error} 샘플 화면을 보여줍니다.`;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}
