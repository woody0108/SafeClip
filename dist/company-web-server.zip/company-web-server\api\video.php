<?php

declare(strict_types=1);

require __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    json_fail(405, 'Only GET is allowed.');
}

$id = clean_document_id((string)($_GET['id'] ?? ''));
$camera = (string)($_GET['camera'] ?? 'front');
if ($id === '' || !in_array($camera, ['front', 'rear'], true)) {
    json_fail(400, 'Invalid video request.');
}

$config = app_config();
$document = firestore_request($config, 'GET', '/submissions/' . rawurlencode($id));
$fields = firestore_fields($document);
$paths = find_video_paths($fields);
$relativePath = $paths[$camera] ?? '';
if ($relativePath === '') {
    json_fail(404, 'Video path is missing.');
}

$storageDir = rtrim((string)($config['storage_dir'] ?? '/volume1/SafeClipUploads'), "/\\");
$filePath = $storageDir . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relativePath);
if (!is_file($filePath)) {
    json_fail(404, 'Video file was not found on NAS.');
}

$extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
if (!in_array($extension, ['mp4', 'mov', 'avi', 'ts'], true)) {
    json_fail(415, 'Unsupported video file.');
}

stream_video($filePath, mime_for_extension($extension));

function stream_video(string $filePath, string $mimeType): void
{
    $size = filesize($filePath);
    if ($size === false) {
        json_fail(404, 'Video file size is unknown.');
    }

    $start = 0;
    $end = $size - 1;
    $status = 200;

    if (isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/', (string)$_SERVER['HTTP_RANGE'], $matches)) {
        $status = 206;
        if ($matches[1] !== '') {
            $start = (int)$matches[1];
        }
        if ($matches[2] !== '') {
            $end = (int)$matches[2];
        }
        if ($start > $end || $end >= $size) {
            header('Content-Range: bytes */' . $size, true, 416);
            exit;
        }
    }

    $length = $end - $start + 1;
    http_response_code($status);
    header('Content-Type: ' . $mimeType);
    header('Accept-Ranges: bytes');
    header('Content-Length: ' . $length);
    header('Content-Disposition: inline');
    if ($status === 206) {
        header("Content-Range: bytes {$start}-{$end}/{$size}");
    }

    $handle = fopen($filePath, 'rb');
    if ($handle === false) {
        exit;
    }

    fseek($handle, $start);
    $remaining = $length;
    while ($remaining > 0 && !feof($handle)) {
        $chunk = fread($handle, min(8192, $remaining));
        if ($chunk === false) {
            break;
        }
        echo $chunk;
        $remaining -= strlen($chunk);
        flush();
    }
    fclose($handle);
    exit;
}

function mime_for_extension(string $extension): string
{
    return match ($extension) {
        'mov' => 'video/quicktime',
        'avi' => 'video/x-msvideo',
        'ts' => 'video/mp2t',
        default => 'video/mp4',
    };
}

function clean_document_id(string $id): string
{
    return preg_match('/^[A-Za-z0-9._-]{1,160}$/', $id) ? $id : '';
}
