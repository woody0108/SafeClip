<?php

declare(strict_types=1);

const FIRESTORE_BASE = 'https://firestore.googleapis.com/v1/projects/%s/databases/(default)/documents';

function app_config(): array
{
    $path = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'config.php';
    if (!is_file($path)) {
        json_fail(500, 'config.php is missing.');
    }

    $config = require $path;
    if (!is_array($config)) {
        json_fail(500, 'config.php must return an array.');
    }

    return $config;
}

function firestore_access_token(array $config): string
{
    $jsonPath = (string)($config['service_account_json'] ?? '');
    if ($jsonPath === '' || !is_file($jsonPath)) {
        json_fail(500, 'Firebase service account JSON file is missing.');
    }

    $service = json_decode((string)file_get_contents($jsonPath), true);
    if (!is_array($service)) {
        json_fail(500, 'Firebase service account JSON is invalid.');
    }

    $now = time();
    $header = base64url_encode(json_encode(['alg' => 'RS256', 'typ' => 'JWT']) ?: '');
    $claim = base64url_encode(json_encode([
        'iss' => $service['client_email'] ?? '',
        'scope' => 'https://www.googleapis.com/auth/datastore',
        'aud' => 'https://oauth2.googleapis.com/token',
        'iat' => $now,
        'exp' => $now + 3600,
    ]) ?: '');

    $unsignedJwt = $header . '.' . $claim;
    $signature = '';
    if (!openssl_sign($unsignedJwt, $signature, (string)($service['private_key'] ?? ''), OPENSSL_ALGO_SHA256)) {
        json_fail(500, 'Could not sign Firebase service account request.');
    }

    $body = http_build_query([
        'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion' => $unsignedJwt . '.' . base64url_encode($signature),
    ]);

    $response = http_request('POST', 'https://oauth2.googleapis.com/token', [
        'Content-Type: application/x-www-form-urlencoded',
    ], $body);

    $payload = json_decode($response['body'], true);
    if ($response['status'] >= 400 || !is_array($payload) || empty($payload['access_token'])) {
        json_fail(500, 'Could not get Firebase access token.');
    }

    return (string)$payload['access_token'];
}

function firestore_request(array $config, string $method, string $path, ?array $body = null): array
{
    $projectId = (string)($config['firebase_project_id'] ?? '');
    if ($projectId === '') {
        json_fail(500, 'firebase_project_id is missing.');
    }

    $url = sprintf(FIRESTORE_BASE, rawurlencode($projectId)) . $path;
    $headers = [
        'Authorization: Bearer ' . firestore_access_token($config),
        'Content-Type: application/json',
    ];

    $response = http_request($method, $url, $headers, $body === null ? null : json_encode($body, JSON_UNESCAPED_UNICODE));
    $payload = json_decode($response['body'], true);

    if ($response['status'] >= 400) {
        json_fail($response['status'], 'Firebase request failed.');
    }

    return is_array($payload) ? $payload : [];
}

function http_request(string $method, string $url, array $headers = [], ?string $body = null): array
{
    $curl = curl_init($url);
    curl_setopt_array($curl, [
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
    ]);

    if ($body !== null) {
        curl_setopt($curl, CURLOPT_POSTFIELDS, $body);
    }

    $responseBody = curl_exec($curl);
    $status = (int)curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
    $error = curl_error($curl);
    curl_close($curl);

    if ($responseBody === false) {
        json_fail(500, $error ?: 'HTTP request failed.');
    }

    return ['status' => $status, 'body' => (string)$responseBody];
}

function firestore_value(array $field): mixed
{
    if (array_key_exists('stringValue', $field)) {
        return $field['stringValue'];
    }
    if (array_key_exists('integerValue', $field)) {
        return (int)$field['integerValue'];
    }
    if (array_key_exists('doubleValue', $field)) {
        return (float)$field['doubleValue'];
    }
    if (array_key_exists('booleanValue', $field)) {
        return (bool)$field['booleanValue'];
    }
    if (array_key_exists('timestampValue', $field)) {
        return $field['timestampValue'];
    }
    if (isset($field['mapValue']['fields']) && is_array($field['mapValue']['fields'])) {
        $result = [];
        foreach ($field['mapValue']['fields'] as $key => $value) {
            $result[$key] = firestore_value($value);
        }
        return $result;
    }

    return null;
}

function firestore_fields(array $document): array
{
    $fields = [];
    foreach (($document['fields'] ?? []) as $key => $value) {
        if (is_array($value)) {
            $fields[$key] = firestore_value($value);
        }
    }

    return $fields;
}

function document_id_from_name(string $name): string
{
    $parts = explode('/', $name);
    return (string)end($parts);
}

function find_video_paths(array $fields): array
{
    $nasFiles = is_array($fields['nasFiles'] ?? null) ? $fields['nasFiles'] : [];

    return [
        'front' => clean_relative_path((string)($nasFiles['front'] ?? $fields['frontVideoPath'] ?? $fields['nasRelativePath'] ?? '')),
        'rear' => clean_relative_path((string)($nasFiles['rear'] ?? $fields['rearVideoPath'] ?? '')),
    ];
}

function clean_relative_path(string $path): string
{
    $path = str_replace('\\', '/', trim($path));
    $path = ltrim($path, '/');

    if ($path === '' || str_contains($path, '..')) {
        return '';
    }

    return $path;
}

function base64url_encode(string $value): string
{
    return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
}

function json_success(array $data): void
{
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => true] + $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function json_fail(int $status, string $message): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => $message], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}
