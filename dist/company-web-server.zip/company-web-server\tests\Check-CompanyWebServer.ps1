$ErrorActionPreference = 'Stop'

$root = Resolve-Path (Join-Path $PSScriptRoot '..')

function Assert-FileContains {
    param(
        [string] $Path,
        [string] $Pattern,
        [string] $Message
    )

    $content = Get-Content -LiteralPath $Path -Raw
    if ($content -notmatch $Pattern) {
        throw $Message
    }
}

function Assert-FileContainsText {
    param(
        [string] $Path,
        [string] $Text,
        [string] $Message
    )

    $content = Get-Content -LiteralPath $Path -Raw
    if (-not $content.Contains($Text)) {
        throw $Message
    }
}

$requiredFiles = @(
    'README.md',
    'config.example.php',
    'index.html',
    'assets/app.js',
    'assets/styles.css',
    'api/bootstrap.php',
    'api/submissions.php',
    'api/status.php',
    'api/video.php'
)

foreach ($file in $requiredFiles) {
    $path = Join-Path $root $file
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Missing required file: $file"
    }
}

$appJs = Join-Path $root 'assets/app.js'
$statusPhp = Join-Path $root 'api/status.php'
$videoPhp = Join-Path $root 'api/video.php'
$submissionsPhp = Join-Path $root 'api/submissions.php'
$config = Join-Path $root 'config.example.php'

Assert-FileContains $appJs 'api/submissions\.php' 'Admin UI must read submissions from the server API.'
Assert-FileContains $appJs 'api/status\.php' 'Admin UI must call the status API.'
Assert-FileContains $appJs 'api/video\.php' 'Admin UI must show videos through the server video API.'
Assert-FileContains $appJs 'completed' 'Review complete button must use the completed Firestore status.'
Assert-FileContains $appJs 'demoSubmissions' 'Admin UI must show sample rows when Firestore is not configured yet.'
Assert-FileContainsText $appJs '설정 전 샘플' 'Admin UI must clearly label sample data.'
Assert-FileContains $appJs 'formatApiError' 'Admin UI must show clear setup errors from the API.'
Assert-FileContains $statusPhp "'completed'" 'Status API must allow completed.'
Assert-FileContains $statusPhp 'updatedAt' 'Status API must update updatedAt.'
Assert-FileContains $videoPhp 'Range' 'Video API must support browser video seeking.'
Assert-FileContains $videoPhp 'SafeClipUploads' 'Video API must read from the NAS upload storage folder.'
Assert-FileContains $submissionsPhp 'submissions' 'Submissions API must read the Firestore submissions collection.'
Assert-FileContains $config 'service_account_json' 'Config must use a server-side Firebase service account file.'

$index = Join-Path $root 'index.html'
Assert-FileContains $index 'aria-current="page"' 'Sidebar must not expose fake clickable navigation buttons.'

Write-Host 'Company web server checks passed.'
