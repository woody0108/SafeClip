<?php

return [
    'firebase_project_id' => 'safeclip-fd26c',
    'service_account_json' => '/volume1/SafeClipSecrets/firebase-service-account.json',
    'storage_dir' => '/volume1/SafeClipUploads',
    'max_submissions' => 50,
];
