# SafeClip NAS 업로드 서버 설치

이 폴더는 Synology NAS Web Station의 `web` 공유 폴더 안에 그대로 넣는 용도입니다.

## NAS에 넣을 위치

DSM File Station에서 아래처럼 넣습니다.

```text
web/
  safeclip-upload-web/
    index.html
    upload-test.html
    config.php
    api/upload.php
```

영상 저장 폴더는 웹 폴더 밖에 둡니다.

```text
SafeClipUploads/
  submissions/
```

## 처음 설정

1. `safeclip-upload-web/config.example.php` 파일을 복사해서 `config.php` 이름으로 만듭니다.
2. `config.php` 안의 `upload_key` 값을 긴 랜덤 문자로 바꿉니다.
3. `SafeClipUploads` 공유 폴더 권한에서 Web Station/PHP가 쓸 수 있게 권한을 줍니다.
4. Web Station에서 이 폴더가 PHP 8.0으로 실행되게 설정합니다.

## 테스트 주소

NAS 주소가 `192.168.0.3`이면 아래 주소로 확인합니다.

```text
http://192.168.0.3/safeclip-upload-web/
http://192.168.0.3/safeclip-upload-web/upload-test.html
```

## 제한

- 한 번에 전방/후방 영상 최대 2개
- 파일 1개당 최대 500MB
- 허용 확장자: `mp4`, `mov`, `avi`, `ts`
- 목록/다운로드/삭제 API 없음

## PHP 설정 주의

500MB 업로드가 되려면 Web Station의 PHP 설정도 커야 합니다.

권장값:

```text
upload_max_filesize = 500M
post_max_size = 1050M
max_execution_time = 300
max_input_time = 300
```
