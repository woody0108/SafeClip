<?php

declare(strict_types=1);

const MAX_FILES_PER_REQUEST = 2;
const MAX_FILE_BYTES = 524288000;
const ALLOWED_EXTENSIONS = ['mp4', 'mov', 'avi', 'ts'];
const FILE_FIELDS = ['front_video', 'rear_video'];

header('Content-Type: application/json; charset=utf-8');

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        fail(405, 'Only POST uploads are allowed.');
    }

    $config = load_config();
    $expectedKey = (string)($config['upload_key'] ?? '');
    if ($expectedKey === '' || str_starts_with($expectedKey, 'replace-this')) {
        fail(500, 'Server upload key is not configured.');
    }

    $providedKey = (string)($_POST['upload_key'] ?? '');
    if (!hash_equals($expectedKey, $providedKey)) {
        fail(401, 'Invalid upload key.');
    }

    $storageDir = rtrim((string)($config['storage_dir'] ?? ''), "/\\");
    if ($storageDir === '') {
        fail(500, 'Server storage_dir is not configured.');
    }

    $files = uploaded_video_files();
    if (count($files) === 0) {
        fail(400, 'Please upload at least one video.');
    }
    if (count($files) > MAX_FILES_PER_REQUEST) {
        fail(400, 'You can upload up to 2 videos at once.');
    }

    $submissionId = clean_name((string)($_POST['submission_id'] ?? 'submission'));
    $userId = clean_name((string)($_POST['user_id'] ?? 'guest'));
    $dateFolder = date('Y-m-d');
    $targetDir = $storageDir . DIRECTORY_SEPARATOR . 'submissions' . DIRECTORY_SEPARATOR . $dateFolder . DIRECTORY_SEPARATOR . $submissionId;
    ensure_directory($targetDir);

    $saved = [];
    foreach ($files as $field => $file) {
        $saved[] = save_video_file($file, $field, $targetDir, $submissionId, $userId, $dateFolder);
    }

    success([
        'saved_count' => count($saved),
        'files' => $saved,
    ]);
} catch (Throwable $error) {
    fail(500, 'Unexpected upload server error.');
}

function load_config(): array
{
    $configPath = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'config.php';
    if (!is_file($configPath)) {
        fail(500, 'config.php is missing. Copy config.example.php to config.php first.');
    }

    $config = require $configPath;
    if (!is_array($config)) {
        fail(500, 'config.php must return a PHP array.');
    }

    return $config;
}

function uploaded_video_files(): array
{
    $files = [];

    foreach (FILE_FIELDS as $field) {
        if (!isset($_FILES[$field])) {
            continue;
        }

        $file = $_FILES[$field];
        if (!is_array($file) || (int)($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            continue;
        }

        $error = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error !== UPLOAD_ERR_OK) {
            fail(400, upload_error_message($field, $error));
        }

        $files[$field] = $file;
    }

    return $files;
}

function save_video_file(array $file, string $field, string $targetDir, string $submissionId, string $userId, string $dateFolder): array
{
    $sizeBytes = (int)($file['size'] ?? 0);
    if ($sizeBytes <= 0) {
        fail(400, "{$field} is empty.");
    }
    if ($sizeBytes > MAX_FILE_BYTES) {
        fail(413, "{$field} is larger than 500MB.");
    }

    $originalName = (string)($file['name'] ?? 'video');
    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    if (!in_array($extension, ALLOWED_EXTENSIONS, true)) {
        fail(415, "{$field} extension is not allowed.");
    }

    if (!is_uploaded_file((string)$file['tmp_name'])) {
        fail(400, "{$field} did not arrive as an HTTP upload.");
    }

    $camera = $field === 'front_video' ? 'front' : 'rear';
    $storedName = date('His') . '_' . $submissionId . '_' . $userId . '_' . $camera . '_' . bin2hex(random_bytes(4)) . '.' . $extension;
    $targetPath = $targetDir . DIRECTORY_SEPARATOR . $storedName;

    if (!move_uploaded_file((string)$file['tmp_name'], $targetPath)) {
        fail(500, 'Could not store uploaded file. Check SafeClipUploads permissions.');
    }

    return [
        'field' => $field,
        'camera' => $camera,
        'stored_name' => $storedName,
        'relative_path' => 'submissions/' . $dateFolder . '/' . $submissionId . '/' . $storedName,
        'size_bytes' => $sizeBytes,
    ];
}

function ensure_directory(string $path): void
{
    if (is_dir($path)) {
        return;
    }

    // 날짜/제출ID 폴더를 자동으로 만듭니다.
    if (!mkdir($path, 0770, true) && !is_dir($path)) {
        fail(500, 'Could not create NAS upload folder.');
    }
}

function clean_name(string $value): string
{
    $value = preg_replace('/[^A-Za-z0-9._-]+/', '-', trim($value)) ?? '';
    $value = trim($value, '.-_');

    if ($value === '') {
        return 'unknown';
    }

    return substr($value, 0, 80);
}

function upload_error_message(string $field, int $code): string
{
    return match ($code) {
        UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => "{$field} exceeds the PHP upload limit.",
        UPLOAD_ERR_PARTIAL => "{$field} arrived only partially.",
        UPLOAD_ERR_NO_TMP_DIR => 'PHP temporary upload folder is missing.',
        UPLOAD_ERR_CANT_WRITE => 'PHP could not write the temporary upload file.',
        UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the upload.',
        default => "{$field} upload failed.",
    };
}

function success(array $data): void
{
    http_response_code(200);
    echo json_encode(['ok' => true] + $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function fail(int $statusCode, string $message): void
{
    http_response_code($statusCode);
    echo json_encode(['ok' => false, 'error' => $message], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}
