$ErrorActionPreference = 'Stop'

$root = Resolve-Path (Join-Path $PSScriptRoot '..')

function Assert-FileContains {
    param(
        [string] $Path,
        [string] $Pattern,
        [string] $Message
    )

    $content = Get-Content -LiteralPath $Path -Raw
    if ($content -notmatch $Pattern) {
        throw $Message
    }
}

$requiredFiles = @(
    'INSTALL.md',
    'config.example.php',
    'index.html',
    'upload-test.html',
    'api/upload.php'
)

foreach ($file in $requiredFiles) {
    $path = Join-Path $root $file
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw "Missing required file: $file"
    }
}

$uploadPhp = Join-Path $root 'api/upload.php'
$config = Join-Path $root 'config.example.php'
$testPage = Join-Path $root 'upload-test.html'

Assert-FileContains $uploadPhp 'MAX_FILES_PER_REQUEST\s*=\s*2' 'upload.php must limit one request to 2 files.'
Assert-FileContains $uploadPhp 'MAX_FILE_BYTES\s*=\s*524288000' 'upload.php must limit each file to 500MB.'
Assert-FileContains $uploadPhp "mp4'.*mov'.*avi'.*ts" 'upload.php must allow mp4, mov, avi, ts.'
Assert-FileContains $uploadPhp 'move_uploaded_file' 'upload.php must store HTTP uploaded files safely.'
Assert-FileContains $uploadPhp 'hash_equals' 'upload.php must compare upload keys safely.'
Assert-FileContains $uploadPhp 'submissions' 'upload.php must store files under a submissions folder.'
Assert-FileContains $config 'SafeClipUploads' 'config example must point to SafeClipUploads.'
Assert-FileContains $testPage 'front_video' 'test page must include front video field.'
Assert-FileContains $testPage 'rear_video' 'test page must include rear video field.'

Write-Host 'NAS upload folder checks passed.'
