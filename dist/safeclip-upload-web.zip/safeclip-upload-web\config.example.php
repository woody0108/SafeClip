<?php

return [
    'upload_key' => 'replace-this-with-a-long-random-upload-key',
    'storage_dir' => '/volume1/SafeClipUploads',
];
